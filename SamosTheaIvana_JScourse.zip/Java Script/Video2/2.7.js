//booleans and comparisons
console.log(true, false, "true", "false");

//methods that can return booleans
let email= 'theasamos001@gmail.com';
let names = ['Solarix', 'Ajax', 'Calypso'];

//let result = email.includes('@');
let result = email.includes('!');
let result2 = names.includes('Ajax');
console.log(result);
console.log(result2);

//comparisons
let age=20;
console.log(age==20);
console.log(age ==30);
console.log(age !=30);
console.log(age > 10);
console.log(age < 10);
console.log(age >= 10);
console.log(age <= 10);
//separador
console.log('********************')
//separador
let nam='Solarix';
console.log(nam=='solarix');
console.log(nam=='Solarix');
console.log(nam > 'calypso');
console.log(nam > 'solarix');
console.log(nam > 'Calypso');