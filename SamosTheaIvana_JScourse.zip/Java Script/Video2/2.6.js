let age=null;
console.log(age, age +9, `Age is ${age}`);