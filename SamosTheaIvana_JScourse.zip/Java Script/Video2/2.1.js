//String typle
console.log('Hello this is Thea');

let email= 'theasamos001@gmail.com';
console.log(email);

//string concatenation
let name= 'Thea';
let surname= 'Samos';

let fullname= name + ' ' + surname;
console.log(fullname);

//getting characters
console.log(fullname[3]);

//string length
console.log(fullname.length);

//string methods
console.log(fullname.toUpperCase());
let result= fullname.toLocaleLowerCase();
console.log(result, fullname);

let index= email.indexOf('@');
console.log(index);