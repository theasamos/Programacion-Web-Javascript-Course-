
let radio=100;
const pi=3.14;

//prints results
console.log(radio, pi);

//operations +,-,*,/,**,%
console.log(30 / 3); //divides 30/3

let resultado=radio % 3; 
console.log(resultado);

// caculates the area of a circle pi*r squared
let area= pi*radio**2;
console.log(area);


let result= 10 * (4-2)**2;
console.log(result);

//add one
let num=10;
//num=num+1;
//num++;
//num--;
//num += 10;
//num -=8;
//num *=5;
//num /=4
console.log(num);


//NaN - not a number 
console.log(5 / 'hello');

let respuesta= 'I have ' + num + ' numbers';
console.log(respuesta);