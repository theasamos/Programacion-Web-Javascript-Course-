//template strings
 const title = 'Fluffy the bunny'
 const author = 'Thea Samos'
 const likes = 450;

 //concatanation way
 let result= 'The act ' + title + ' created by '+ author + ' has '+ likes + ' likes';
 console.log(result);

 //template string way
 let result2= `The act ${title} created by ${author} has ${likes} likes`;
 console.log(result2);

 //template html 
 let html = `
 <h2>${title}</h2>
 <p>${author}</p>
 <span>This site has ${likes} likes</span>
 `;
 console.log(html);