//creation of a vector using atrings
let pets = ['cat', 'dog','bird'];
//change the second value of the vector 
//pets[1]= 'turtle';
console.log(pets[1]);

let age= [10,12,14,15,19];
console.log(age[2]);

let random=['Ajax','Solarix', 10, 45, 7];
console.log(random);

//vector size
console.log(pets.length);

//array methods
let result = pets.join(',');
console.log(result);

let result2 = pets.indexOf('pig');
console.log(result2);

let result3 = pets.concat(['snake', 'parrot']);
console.log(result3);

let result4 = pets.push('rabbit');
result4=pets.pop();
console.log(result4);