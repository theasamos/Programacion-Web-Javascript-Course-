//common string methods
let email= 'theasamos001@gmail.com';

// the number of the vector where the second to last letter is found will be printed
let result=email.lastIndexOf('g');
console.log(result);

//prints each letter from one point to the next
let result2=email.slice(0,9);
console.log(result2);

//prints each letter from one point to the next
let result3=email.substr(4,11);
console.log(result3);

//Replaces the first letter by the second letter, only once
let result4=email.replace('s','a');
console.log(result4);