let age=25;

//lost comparison

console.log(age == 25);
console.log(age == '25');
console.log(age != 25);
console.log(age != '25');

console.log('-------------------');

//comparison strick 
console.log(age === 25);
console.log(age === '25');
console.log(age !== 25);
console.log(age !== '25');