// Types of conversions
let points='100';
console.log(points+1);
console.log(typeof points);
points=Number(points);
console.log(points+1);
console.log(typeof points);


console.log('-------------------');


let resultado = Number ('hello');//Can't convert a letter to a number
console.log(resultado);

let resul= String(50);
console.log(resul, typeof resul);

let result = Boolean(45);//true because it's not 0
console.log(result, typeof result);
result = Boolean(0);//false
console.log(result, typeof result);
result = Boolean('0');//true because it's null
console.log(result, typeof result);
result = Boolean('');//false
console.log(result, typeof result);