//Change the style of an element by directly configuring the style attribute

const title = document.querySelector('h1');

//Change color and put margin
//title.setAttribute('style', 'margin:50px;')

//remove margin and add color
console.log(title.style);

//Show style and color on concole
console.log(title.style);
console.log(title.style.color);

//Has margen and color
//Is not overwritten because new property was added
title.style.margin = '50';
title.style.color = 'yellow';
title.style.fontSize = '60px'


title.style.margin = '';
