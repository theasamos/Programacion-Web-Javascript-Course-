//Get and update HTML attributes

//value of the 'href?console
const link = document.querySelector('a');
console.log(link.getAttribute('href'));

//Navegator link is changed(elements)
link.setAttribute( 'href', 'https://www.helloeveryone.com');

//Internal text is changed 
link.innerText = 'Everyone is doing very well today';

//exaple
const mssg = document.querySelector('p');
console.log(mssg.getAttribute('class'));

//Changed the name of the error class to sucess
mssg.setAttribute('class', 'success');

//Change tag color
mssg.setAttribute('style', 'color:red;')  
