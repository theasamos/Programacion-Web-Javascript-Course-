//Consult elements
const paras = document.querySelectorAll('p');

//Recorrerlos
paras.forEach(p => {
    
    //console.log(p.innerText);

    //console.log(p.textContent)

    // "error"
    if(p.textContent.includes('error')) {
        p.classList.add('error');
    }
    //"success"
    if(p.innerText.includes('success')){
        p.classList.add('success');   
    }
});


//Alternate clases 
const title = document.querySelector('.title')
//Title class will alternate with test class
//  <h1 class="title">The DOM</h1>
title.classList.toggle('test');
title.classList.toggle('test');
//if repeated, is removed 