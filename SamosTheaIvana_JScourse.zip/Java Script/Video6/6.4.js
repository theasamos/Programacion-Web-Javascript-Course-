//Change internal text elements and HTML

//change paragraph text
const para1 = document.querySelector('p');
//console.log(para1.innerText);

//para1.innerText = 'Hello everyone';

//add old text to the new one
//para1.innerText += 'Hello everyone';


const paras = document.querySelectorAll('p');
//paras.forEach(para => {
  //  console.log(para.innerText);
//});


//paras.forEach(para => {
  //  console.log(para.innerText);
    //para.innerText += ' Hello everyone';
//});

//HTML

// content goes into div
const content = document.querySelector('.contenido');
//console.log(content.innerHTML);

//changes html internal context to div
 //content.innerHTML = '<h2>Hello everyone</h2>';

 //changes p paragraph elements to h2 elements
 //content.innerHTML += '<h2>Hello everyone</h2>'

 //List of persons to generate html for each

 const gente = ['Amaya','Thea', 'Gloria '];
gente.forEach(persona =>{
    content.innerHTML += `<p>${persona}</p>`;
})
 