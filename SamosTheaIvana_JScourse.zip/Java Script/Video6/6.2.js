
//Take an element from DOM
const para1 = document.querySelector('p');
console.log(para1);

//'.' bescouse its a class typw
const para2 = document.querySelector('.error');
console.log(para2);

//div. error 
const para3 = document.querySelector('div.error');
console.log(para3);

//In elements is coppied from "Copy selector" and pasted in > h1
const para4 = document.querySelector('body > h1');
console.log(para4); 

//Take all elements from Dom, using the same property
//creates node in list
const paras = document.querySelectorAll('p');
console.log(paras);

//Select a specific element in the list
console.log(paras[0]);
console.log(paras[2]);

//In this arrow function, goes through node list and for each node we have access into the return function called

paras.forEach(para => {
 console.log(para);
})

//A list of all the elements that have .error
const errors = document.querySelectorAll('.error');
console.log(errors);


