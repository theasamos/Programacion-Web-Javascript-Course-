

//get an element by ID 
const title = document.getElementById('page-title');
console.log(title);

//get elements by their class name 

//Coleccion HTML
const errors = document.getElementsByClassName('error');
console.log(errors);

//[0] get first element
console.log(errors[0]);

// Foreach cannot be used for each method in the HTML collection
//Produces error
//errors.forEach(error => {
 //console.log(error); 
//});

//get elements by their tag name 
//Coleccion HTML
const paras = document.getElementsByTagName('p');
console.log(paras); 

//can get a specific element
console.log(paras[1]);