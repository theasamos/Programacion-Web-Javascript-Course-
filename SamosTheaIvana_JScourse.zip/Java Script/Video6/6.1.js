//DOM (modelos de objetos del documento)

//Interactuar con el navegador

//Agregando, eliminando o cambiando contenido de una pag web