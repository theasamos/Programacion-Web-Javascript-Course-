   //Add and remove class element

//console shows  "DomTokenList", error
const content = document.querySelector('p');
console.log (content.classList);

//Gets classes that have an element

//Adds a class, and removes index
//content.classList.add('error');

//error class is removed
//error is also removed
content.classList.remove('error')

//Success list is added
//Success style is added
content.classList.add('success');