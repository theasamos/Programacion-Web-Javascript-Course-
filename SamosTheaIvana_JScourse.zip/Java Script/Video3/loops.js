//loops

const names = ['Akame', 'Nyx', 'Misha'];

for(let i= 0; i < names.length; i++){
    //console.log(names [i]);

    let html = `<div> ${names[i]} </div>`;
    console.log(html);
}
