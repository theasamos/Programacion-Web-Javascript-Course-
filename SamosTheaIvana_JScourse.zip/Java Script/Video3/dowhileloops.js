//do while loops

let i = 2;

do{
console.log('val of i is:', i);
i++;
} while(i < 5);

