//if statements
// const age = 25;

// if(age > 20){
//     console.log('You are over 20 years old');
// }

// const ninjas = ['Thea', 'Amaya', 'Jesus', 'Gloria'];

// if(ninjas.length > 4){
//     console.log("That's a lot of ninjas");
// }

const password = 'password123';

if(password.length >= 8){
    console.log('That password is long enough')
}