//else if statements

const password = 'pass';

if(password.length >=12){
    console.log('That password is mighty strong');
} else if(password.length >= 8){
    console.log('That password is long enough')
} else{
    console.log('That password is not long enough');
}
