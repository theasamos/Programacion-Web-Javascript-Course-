//while loops
const names = ['Akame', 'Nyx', 'Misha'];

// let i =0;
// while (i < 5){
//     console.log('in loop:', i);
//     i++;
// }

let i = 0;
while (i < names.length){
    console.log(names[i]);
    i++;
}