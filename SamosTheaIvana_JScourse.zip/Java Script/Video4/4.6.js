const name = 'Thea'

//functions
const greet = () => 'Hello';

let resultOne = greet();
console.log(resultOne);


//methods
let resultTwo = name.toUpperCase();
console.log(resultTwo);