//arguments & parameters

const speak = function(name, time){ 
    console.log(`Good  ${time} ${name}`);
};

speak('Thea', 'morning'); //argument