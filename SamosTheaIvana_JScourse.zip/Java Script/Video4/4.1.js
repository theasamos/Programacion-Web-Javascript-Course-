//function declaration
function greet(){
    console.log('Hello uwu');
}

//functions expression
const speak = function(){
    console.log('Good day');
};

greet();
speak();