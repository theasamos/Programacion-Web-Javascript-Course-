//callbacks & foreach


//EXAMPLE 1 
/*
const myFunc = (callbackFunl) => {
    //do something
    let value = 50;
    callbackFunc(value);
};

// myFunc (function(value){
//     //do something
//     console.log(value);
// });

myFunc (value => {
    //do something
    console.log(value);
}); */ 



//callbacks & foreach

//EXAMPLE 2
/*
let people = ['Ajax', 'Calypso', 'Solarix', 'Hitomi', 'Tina'];

people.forEach(function(person){
    console.log(person);
}); */ 

//callbacks & foreach ARROW function

let people = ['Ajax', 'Calypso', 'Solarix', 'Hitomi', 'Tina'];

const logPerson = (person, index) =>{
    console.log (`${index} - hello ${person}`);
}
people.forEach(logPerson);
