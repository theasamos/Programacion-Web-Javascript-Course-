//arrow function

//const calcArea = radius =>3.14 * radius**2; 
//OR

const calcArea = radius => {
    return 3.14 * radius**2;
};

const area = calcArea(5);
console.log('area');