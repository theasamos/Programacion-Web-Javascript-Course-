//Types of primitives and references

//Primitives
//let scoreOne = 50;
//let scoreTwo = scoreOne;

//stack primitive value

//console.log('scoreOne: ${scoreOne}', 'scoreTwo: ${scoreTwo}');

//scoreOne=100;
//console.log('scoreOne: ${scoreOne}', 'scoreTwo: ${scoreTwo}');



//Reference values


const userOne = {name: 'ryu', age: 30};
//create a copy of the user variable to configure it
const userTwo = userOne;

console.log(userOne, userTwo);
//if you change the name of one, both will change
userOne.age = 40;
console.log(userOne, userTwo);