//objet literals

  //make an object
let user = {
    //give properties key values
    name: 'Thea',
    age: 20,
    email: 'theasamos001@gmail.com',
    location: 'Belize',
    //Diferentes blogs
    blogs:['Bears are cute','Healthy eating']
};
//register user object in cosole
console.log(user);

console.log(user.name);

//user.age = 35; 
console.log(user.age);

console.log(user['location']);
user['name'] = 'Samos';
console.log(user['name']);

console.log(typeof user);
