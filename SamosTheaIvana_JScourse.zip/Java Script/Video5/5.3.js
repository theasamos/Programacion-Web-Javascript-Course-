


//console.log(blogs);
let user = {
    name: 'Thea',
    age: 30,
    email: 'theasamos@gmail.com',
    location: 'Belize',
    blogs:[
        {title:'Bears are fun', likes: 70},
    {title:'Healthy eating', likes: 50}
    ],
    login(){
        console.log('the user logged in');
    },

    logout(){
        console.log('the user logged out');
    },
    logBlogs(){
        //register different blogs in the console
        //we need to acces this function
        console.log('this user has written the following blogs');
            this.blogs.forEach(blog => {
            console.log(blog.title,blog.likes);
            
        });

    }
      
};

user.logBlogs();