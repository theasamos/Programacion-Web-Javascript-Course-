//Mathematical object that has several properties and methods grouped into them

console.log(Math);
//pi a constant
console.log(Math,PI);

console.log(Math,E);

//create a constant and establish a point 7.7

const area=7.7;

//different methods can be used 
console.log(Math.round(area));
console.log(Math.floor(area));
console.log(Math.ceil(area));
console.log(Math.trunc(area));

//random numbers constant

const random = Math.random();

console.log(random);
//The following is to get a random number between 1-100
console.log(Math.round(random*100));