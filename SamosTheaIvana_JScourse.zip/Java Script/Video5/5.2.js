// object literals

let user = {
    name: 'Thea',
    age: 30,
    email: 'theasamos@gmail.com',
    location: 'Belize',
    blogs:['Bears are fun','healthy eating'],
    

    login: function () {
        // consult the register of the user login 
        console.log('the user logged in');
    },
    //this way we can add new methods 
    logout: function(){
        console.log('the user logged out');
    },
    //another method that prints all the blogs
    logBlogs: function(){

    }
};
//call login method and view it on console

user.login();
//user point closes session
user.logout();

const name = 'Ajax';
//chain object
name.toUpperCase();